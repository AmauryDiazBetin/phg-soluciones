import React, { useState } from 'react';
import RFIDAdminPanel from './components/RFIDAdminPanel';

const App = () => {
  return (
    <div className="App">
      <RFIDAdminPanel />
    </div>
  );
};

export default App;

// DONE